package edu.cmu.tetradapp.model.calculator.expression;

/**
 * Marking interface to indicate that something is boolean.
 *
 * @author Tyler Gibson
 */
public interface BooleanExpression {
    
}
