package edu.cmu.tetradapp.model.calculator.expression;

/**
 *
 * @author Tyler Gibson
 */
public class ExpressionInitializationException extends Exception{


    public ExpressionInitializationException(String message){
        super(message);
    }

    
}
